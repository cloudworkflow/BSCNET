```bash
 _____ ____  _   _ ___ _____       ____ _____ _   _ 
| ____|  _ \| \ | |_ _| ____|     / ___| ____| \ | |
|  _| | |_) |  \| || ||  _| _____| |  _|  _| |  \| |
| |___|  _ <| |\  || || |__|_____| |_| | |___| |\  |
|_____|_| \_\_| \_|___|_____|     \____|_____|_| \_|
```

The `ERNIE-GEN` (including all our pre-trained models) has been released at [here](https://github.com/PaddlePaddle/ERNIE/tree/repro/ernie-gen).
